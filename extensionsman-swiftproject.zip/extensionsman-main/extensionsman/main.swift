//
//  main.swift
//
// Created by Charles Edge
//

import Foundation

let extensionMan = ExtensionMan()
extensionMan.staticMode()
