//
//  main.swift
//
//  Charles Edge
//

import Foundation

let extensionMan = ExtensionMan()
extensionMan.staticMode()
